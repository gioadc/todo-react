var React = require('react');
var ReactDOM = require('react-dom');

var AppTodo = require('AppTodo');

require('style!css!app/styles/styles.css');

ReactDOM.render(<AppTodo /> ,  document.getElementById("app"));