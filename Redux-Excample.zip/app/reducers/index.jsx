// Name reducer and action genarators
// ---------------
export var nameReducer = (state = 'Minh', action) => {
    switch (action.type) {
        case 'CHANGE_NAME':
            return action.name;
    
        default:
            return state;
    }
};

// Hobbies reducer and action genarators
// ----------------
var nextHobbyId = 1;
export var hobbiesReducer = (state = [], action) => {
    switch (action.type) {
        case 'ADD_HOBBY':
            return [
                ...state,
                {
                    hobbyId: nextHobbyId++,
                    hobby: action.hobby
                }
            ];
        
        case 'REMOVE_HOBBY':
            return state.filter((hobby) => hobby.hobbyId !== action.hobbyId);
    
        default:
            return state;
        
    }
};

// Map reducer and action genarators
// ----------------
export var mapReducer = (state = {isFetching: false, callback: undefined, url: undefined}, action) => {
    switch (action.type) {
        case 'START_LOCATION_FETCH':
            return {
                isFetching: true,
                url: undefined,
                callback: action.callback
            }

        case 'COMPLETE_LOCATION_FETCH':
            return {
                isFetching: false,
                url: action.url,
                callback: state.callback
            }
    
        default:
            return state;
    }
};