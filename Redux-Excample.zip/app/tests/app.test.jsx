var expect = require('expect');

describe('App', () => {
  it('should properly run tests', () => {
    expect(1).toBe(1);
  });
});
