var redux = require('redux');
var axios = require('axios');

var actions = require('./actions/index');
var store = require('./store/configureStore').configure();

var stateDefault = {
    name: 'Minh',
    age: 500,
    hobbies: []
};


// ==================================

// Main reducer


// get state
var currentState = store.getState();

console.log('Current state', currentState);

// dispatch to change state with action param
// store.dispatch({
//     name: 'Long',
//     type: 'CHANGE_NAME'
// });
store.dispatch(actions.changeName('Long'));

currentState = store.getState();
console.log('The name has been changed to', currentState);

// subcribe to changing in state and get object function to unsubcribe
var unsubscribe = store.subscribe(() => {
    var currentState = store.getState();
    console.log('The state is', currentState);

    document.getElementById('app').innerHTML = currentState.name;

    if(!currentState.map.isFetching
        && currentState.map.url
        && currentState.map.callback) {
        var callback = currentState.map.callback;
        callback(currentState.map.url);
    }
});

// store.dispatch({
//     type: 'CHANGE_NAME',
//     name: 'MINH TRẦN'
// });
store.dispatch(actions.changeName('MINH TRẦN'));

// unsubscribe();

// store.dispatch({
//     type: 'CHANGE_NAME',
//     name: 'KIM LONG'
// });
store.dispatch(actions.changeName('KIM LONG'));

store.dispatch(actions.addHobby('Listen to music'));

store.dispatch(actions.addHobby('Somthing else'));

store.dispatch(actions.removeHobby(1));

// Call a asynchronous action with callback is a anonymous function
store.dispatch(actions.fetchLocation((url) => {
    document.getElementById('locationApp').innerHTML = '<a href="' + url + '" title="Your location on Google Map base on your ip">Your location on Google Map base on your ip</a>';
}));